
// import './style/st.css';

window.addEventListener("load", () => {
  const loader = document.querySelector(".loader");

  loader.classList.add("loader--hidden");

  loader.addEventListener("transitionend", () => {
    document.body.removeChild(loader);
  });
});


// Fetch API untuk mendapatkan dan menampilkan catatan baru
const baseUrl = 'https://notes-api.dicoding.dev/v2';
const notesList = document.getElementById('listnotes');
const getNote = async () => {
  const requestOptions = {
    method: 'GET',
};
  try {
    const response = await fetch(`${baseUrl}/notes`, requestOptions);

    // Check for successful response status code (usually 200)
    if (!response.ok) {
      throw new Error(`HTTP error! Status: ${response.status}`);
    }

    const responseJson = await response.json();

    if (responseJson.error) {
      showResponseMessage(responseJson.message);
    } else {
      renderAllNotes(responseJson.data || []);
    }
  } catch (error) {
    console.error('Error fetching notes:', error);
    showResponseMessage('Failed to load notes. Please check your internet connection or try again later.');
  }
  
};
let existingNotes = []; // Assuming you have an empty array to store notes

const getExistingNotes = () => {
  // Implement logic to retrieve existing notes from your data source (e.g., localStorage, array)
  return existingNotes;
}
const insertNotes = async (note) => {
  try {
    const options = {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(note)
    };

    const response = await fetch(`${baseUrl}/notes`, options);
    const responseJson = await response.json();

    if (responseJson.error) {
      showResponseMessage(responseJson.message);
    } else {
      // Update local list directly with new note
     
      getNote();// Assuming getExistingNotes function exists
      showResponseMessage('Catatan berhasil ditambahkan!');
    }
  } catch (error) {
    showResponseMessage(error);
  }
};

const updateNote = async (note) => {
  try {
    const options = {
      method: 'PUT',
      headers: {
        'Content-Type': 'application/json',
        'X-Auth-Token': '12345'
      },
      body: JSON.stringify(note)
    }
 
    const response = await fetch(`${baseUrl}/notes`, options);
    const responseJson = await response.json();
 
    showResponseMessage(responseJson.message);
    getNote();
  } catch (error) {
    showResponseMessage(error);
  }
};
const removeBook = (noteId) => {
  fetch(`${baseUrl}/delete/{noteId}`, {
    method: 'DELETE',
    headers: {
      'X-Auth-Token': '12345'
    }
  }).then(response => {
    return response.json();
  }).then(responseJson => {
    showResponseMessage(responseJson.message);
    getBook();
  }).catch(error => {
    showResponseMessage(error);
  });
};
const renderAllNotes = (notes) => {
  const listNoteElement = document.querySelector('#listnote');
  listNoteElement.innerHTML = ''; // Clear existing content

  if (notes && notes.length > 0) {
    notes.forEach(note => {
    listNoteElement.innerHTML += `
    <div class="Catatancontainer">
    <div class="catatan">
    <h3 class="judul-catatan">${note.title}</h3>
    <p class="isi-catatan">${note.body}</p>
    <button type="button" class="button-delete" id="${note.id}">Hapus</button>
  </div>
  </div>
    `;
  });
} else {
    // Handle empty notes scenario (optional)
    listNoteElement.innerHTML = '<p>Tidak ada catatan yang ditemukan.</p>';
  }

  const buttons = document.querySelectorAll('.button-delete');
  buttons.forEach(button => {
    button.addEventListener('click', event => {
      const noteId = event.target.id;
      removeNote(noteId);
    });
  });
};

const showResponseMessage = (message = 'Check your internet connection') => {
  alert(message);
};

const removeNote = async (noteId) => {
  try {
    const response = await fetch(`${baseUrl}/notes/${noteId}`, {
      method: 'DELETE',
      headers: {
        'Content-Type': 'application/json',
        'X-Auth-Token': 'YOUR_AUTH_TOKEN' // Replace with your actual auth token
      }
    });

    // Check for successful response status code (usually 200)
    if (!response.ok) {
      throw new Error(`Failed to delete note: ${response.statusText}`);
    }

    const responseJson = await response.json(); // Parse response (optional)

    // Update UI to reflect deletion (optional)
    const deletedNoteElement = document.getElementById(noteId); // Assuming IDs are unique
    if (deletedNoteElement) {
      deletedNoteElement.parentElement.remove(); // Remove the note element
    } else {
      console.warn(`Note with ID ${noteId} not found in UI, but may be deleted on the server.`);
    }

    console.log(`Note ${responseJson?.id} (if available) deleted successfully.`); // Handle success message

    // Optionally, refetch all notes to update the list (consider performance implications)
    // getNote();
  } catch (error) {
    console.error('Error deleting note:', error);
    showResponseMessage('Failed to delete note. Please try again later.'); // User-friendly error message
  }
};


document.addEventListener('DOMContentLoaded', () => {

  // Assuming elements exist in your HTML for note creation
  const inputNoteTitle = document.querySelector('#judulCatatan'); // Title input
  const inputNoteBody = document.querySelector('#isiCatatan'); // Body input
  const buttonSaveNote = document.querySelector('form button[type="submit"]'); // Save button (adjust selector if needed)

  buttonSaveNote.addEventListener('click', function (event) {
    event.preventDefault(); // Prevent default form submission

    const note = {
      title: inputNoteTitle.value,
      body: inputNoteBody.value
    };

    insertNotes(note);

    // Clear form fields after successful creation (optional)
    inputNoteTitle.value = '';
    inputNoteBody.value = '';
  });

  getNote();
});
